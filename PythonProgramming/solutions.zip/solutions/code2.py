M = np.array([[1,4,-3],[4,2,0],[-3,0,3]])

arg1 = np.dot(M.T,M)
arg2 = linalg.inv(arg1)

Z = np.dot(arg2,np.dot(M,M))
print(Z)
