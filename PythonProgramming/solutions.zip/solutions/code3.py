temp_area = 0
for i in range(0,len(x)-1):
    temp_area = temp_area + delta*((y[i]+y[i+1])/2)
print(temp_area)

temp_area2 = 0
for i in range(0,len(x)-1):
    temp_area2 = temp_area2 + delta*y[i]
print(temp_area2)