## Version 1

theta = np.arange(0.0,2*np.pi,0.01)
x = np.cos(theta)
y = np.sin(theta)

plt.plot(x,y)
plt.axis('equal')
plt.show()

## Version 2 

theta = np.arange(0.0,2*np.pi,0.01)
z = np.cos(theta) + 1j*np.sin(theta)

plt.plot(np.real(z),np.imag(z))
plt.axis('equal')
plt.show()