## Version 1

sol = []
for i in range(0,len(x)-1):
    if y[i]*y[i+1] <= 0:
        sol.append(x[i])     
print(sol)

## Version 2

f2 = [4,10,-20,-10]
x = np.roots(f2)
print(x)

## Version 3

from sympy.solvers import solve
from sympy import Symbol
from math import sqrt

x = Symbol('x')
sol = solve(4*x**3 + 10*x**2 - 20*x - 10, x)

print(sol[0])

## Version 4 

def soltofloat(sol):
    result = []
    for i in range(0,len(sol)):
        s = str(sol[i]).replace('I', '1j')
        result.append(float(np.real(eval(s))))
    return result

print(soltofloat(sol))