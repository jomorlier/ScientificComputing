n = 10000
x = -1 + 2*np.random.rand(n,2)
count = 0
for j in range(0,n):
    if np.linalg.norm(x[j,:]) <= 1 :
        count = count + 1

pi_est = (count/n)*4
print(pi_est)

# visualize
w = np.arange(0.0,2*np.pi,0.01)
z = np.cos(w) + 1j*np.sin(w)


plt.plot(x[:,0],x[:,1],'bo',ms = 1)
plt.plot(np.real(z),np.imag(z),'r',lw=3)
plt.axis('equal')
plt.show()