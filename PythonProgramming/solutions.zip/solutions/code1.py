import numpy as np
import matplotlib.pyplot as plt
%matplotlib inline
from scipy import linalg
from math import pi


t = np.arange(0.0,3.0,0.01)
x1 = np.sin(t)
x2 = np.cos(t)

a1 = 1.5
a2 = 3
a3 = 1

f = a1*(x1**2) + a2*(x2**2) + a3

plt.plot(t,f)
plt.show()

I = np.argmin(f)

print(t[I])